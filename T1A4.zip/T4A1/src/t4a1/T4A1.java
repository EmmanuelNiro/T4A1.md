package t4a1;

import java.util.Scanner;

public class T4A1 {

    public static void main(String[] args) {

        //ejercicio1();
        //ejercicio2();
        //ejercicio3();
        ejercicio4();
    }

    public static void ejercicio1() {
        Scanner scanner = new Scanner(System.in);

        int numero = 0;
        int limite;

        System.out.println("Ingresar el numero");
        limite = scanner.nextInt();

        while (numero < limite) {
            numero++;
            System.out.println("\n" + numero);

        }

    }

    public static void ejercicio2() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Piezas a confeccionar");
        int p = scanner.nextInt();
        int n = 0;
        int tallaM=0;
        int tallaS=0;
        int tallaL=0;
        int tallaXL=0;

        while (n < p) {

            n++;
            System.out.println("\nTalla: ");
            String talla = scanner.next();
            
            if (talla.equals("s")|| talla.equals("S")){
                tallaS++;
            } else if (talla.equals("m")|| talla.equals("M")) {
                tallaM++;
            }else if (talla.equals("l")|| talla.equals("L")){
                tallaL++;
            }else if (talla.equals("xl")|| talla.equals("XL")){
                tallaXL++;
                
            }
            
            
        }

        System.out.println("Talla chica: "+ tallaS);
        
        System.out.println("Talla mediana: "+ tallaM);
        
        System.out.println("Talla grande: "+ tallaL);
        
        System.out.println("Talla extra grande: "+ tallaXL);
        
        
        
    }
    
    public static void ejercicio3() {
    Scanner scanner = new Scanner(System.in);
      int a= 0;
      int r=0;
      float calif;
      int n=1;
      
        System.out.println("Cantidad de calificaciones");
      int lim=scanner.nextInt();
      
      
      while(n <= lim){
          
          n++;
          System.out.println("Introdusca la calificacion del 0 al 100");
          calif = scanner.nextFloat();
          if(calif>=70 && calif<=100){
              
              a++;
              
              
          }else if(calif <= 69){
              r++;
          }
        
                
       }
        System.out.println("Alumnos aprobados: " +a);
        System.out.println("Alumnos reprobados: " +r);
       
    }
    public static void ejercicio4() {
     Scanner scanner = new Scanner(System.in);

        int numero;
        int limite;
       
        
        
        System.out.println("Ingrese un numero");
        numero = scanner.nextInt();
        
        System.out.println("Ingresar el limite");
        limite = scanner.nextInt();

      
        
        while (numero <= limite) {
           numero++;
            
            System.out.println(numero+numero);

        }
        
        
        
    }
}
            
            
        

        
    
    
            
            
        
        
        
        
        
        
        
    
    
    
    

